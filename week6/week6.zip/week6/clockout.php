<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8"> 
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  </head>
  <body>
      <div class="container">
          <h2 class="page-header">Time Card</h2>
          <h1><time>00:00:00</time></h1>
          <a href="timecard.php"><input type="button" class="btn btn-danger btn-lg" value="clock out"></a>
      </div>
  </body>
  <script src="script.js"></script>
</html>

