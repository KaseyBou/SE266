<!DOCTYPE html>
<style>
     #footer {
   position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: greenyellow;
   color: white;
   text-align: center;
}
</style>
<div id="footer">
          <h1>Copyright 2018 © <small style="color: black;">by Kasey Bourdier</small></h1>
 </div>