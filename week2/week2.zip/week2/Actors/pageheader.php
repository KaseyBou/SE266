<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8"> 
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  </head>
  <body>
      <div class ="container">
          <h1 class="page-header">Lab 2 Actors <small>- Kasey Bourdier</small></h1>
          <!-- here I have my table -->
          <br />
          <br />
          <br />
          <br />
          <table class="table">
                <tr>
                  <th>Firstname</th>
                  <th>Lastname</th>
                  <th>dob</th>
                  <th>height</th>
                </tr>
            </table>
          <div class="panel panel-info">
            <div class="panel-heading">Add Actors</div>
                <div class="panel-body">
                    <li><a href="http://192.168.10.10/SE266/week2/Actors/add.php">page add actors</a></li>
                </div>
          </div>
          <div class="panel panel-info">
            <div class="panel-heading">View Actors</div>
                <div class="panel-body">
                    <li><a href="http://192.168.10.10/SE266/week2/Actors/view.php">page view actors</a></li>
                </div>
          </div>
      </div>
  </body>
</html>

